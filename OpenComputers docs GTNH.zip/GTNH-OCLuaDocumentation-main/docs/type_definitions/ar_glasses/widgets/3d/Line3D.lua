---@meta _

---@class Line3D: IAlpha, IColorizable, I3DVertex, IScalable, IThroughVisibility