---@meta _

---@class Dot3D: IAlpha, IScalable, IColorizable, I3DPositionable, IThroughVisibility, IViewDistance