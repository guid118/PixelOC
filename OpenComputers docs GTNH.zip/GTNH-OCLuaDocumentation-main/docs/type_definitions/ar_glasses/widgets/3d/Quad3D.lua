---@meta _

---@class Quad3D: Triangle3D