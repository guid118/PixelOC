---@meta _

---@class Triangle3D: IAlpha, IColorizable, IThroughVisibility, I3DVertex