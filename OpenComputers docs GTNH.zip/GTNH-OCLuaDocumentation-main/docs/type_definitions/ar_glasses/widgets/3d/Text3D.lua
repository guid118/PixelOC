---@meta _

---@class Text3D: IViewDistance, ILookable, I3DPositionable, ITextable, IColorizable, IScalable, IAlpha, IThroughVisibility