---@meta _

---@class Text2D: ITextable, IRotatable