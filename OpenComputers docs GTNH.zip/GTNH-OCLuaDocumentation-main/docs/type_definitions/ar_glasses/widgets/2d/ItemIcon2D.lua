---@meta _

---@class ItemIcon2D: IItemable, IPositionable, IScalable, IRotatable