---@meta _

---@class Rect2D: IPositionable, IResizable, IColorizable, IAlpha