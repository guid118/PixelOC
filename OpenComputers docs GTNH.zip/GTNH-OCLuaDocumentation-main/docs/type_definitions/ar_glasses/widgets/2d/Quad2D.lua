---@meta _

---@class Quad2D: Triangle2D