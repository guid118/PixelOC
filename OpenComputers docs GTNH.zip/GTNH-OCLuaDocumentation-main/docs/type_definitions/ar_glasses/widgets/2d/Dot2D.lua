---@meta _

---@class Dot2D: IPositionable, IColorizable, IAlpha, IScalable