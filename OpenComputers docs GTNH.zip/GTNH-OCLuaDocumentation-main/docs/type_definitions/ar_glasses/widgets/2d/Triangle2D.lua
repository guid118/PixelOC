---@meta _

---@class Triangle2D: IColorizable, IAlpha, I2DVertex