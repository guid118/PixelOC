---@meta _

---@class CropNBT
---@field resistance integer the resistance value of the crop
---@field gain integer the gain value of the crop
---@field growth integer the growth value of the crop
---@field tier integer the tier of the crop
---@field name string the name of the crop