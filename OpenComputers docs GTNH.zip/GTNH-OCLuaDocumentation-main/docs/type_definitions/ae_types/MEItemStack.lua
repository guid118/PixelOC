---@meta _

---@class MEItemStack: ItemStack
---@field isCraftable boolean # True if the item is craftable