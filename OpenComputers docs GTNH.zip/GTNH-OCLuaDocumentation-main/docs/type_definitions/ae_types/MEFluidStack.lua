---@meta _

---@class MEFluidStack: FluidStack
---@field isCraftable boolean # True if the fluid is craftable