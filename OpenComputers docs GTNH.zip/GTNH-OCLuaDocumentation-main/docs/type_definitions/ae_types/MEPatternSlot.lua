---@meta _

---@class MEPatternSlot
---@field name  string  # The localised name of the item in the slot.
---@field count integer # The amount set in the slot.