---@meta _

---@class MEPattern: MEItemStack
---@field inputs  MEPatternSlot[] # The inputs of the pattern
---@field outputs MEPatternSlot[] # The outputs of the pattern