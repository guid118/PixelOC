---@meta _

---Refers to ME chests
---@class tilechest: aemultipart
---@field type 'tilechest'

-- Empty on purpose, this component is just a reskined aemultipart