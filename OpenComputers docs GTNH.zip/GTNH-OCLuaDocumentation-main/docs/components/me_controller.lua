---@meta _

---@class me_controller: CommonNetworkAPI, aemultipart
---@field type "me_controller"
local me_controller = {}


-- empty on purpose, it's just a mash of the CommonNetworkAPI and aemultipart types